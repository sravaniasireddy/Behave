__author__ = 'pmacharl'
from .automation_home_page import *
from .automation_home_page1 import AutomationHomePage1
from .login_page import LoginPage
from .checkout_page import *
from .order_confirmation_page import *
from .order_summary_page import *
from .payment_method_page import *
from .shipping_address_page import *
from .shopping_cart_summary_page import *
from .summer_dresses_catalog_page import *
from .address_page import *